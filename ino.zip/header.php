<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <title>INNOMEP</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width">

        <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->

        <link rel="stylesheet" href="rsd/css/normalize.css">
        <link rel="stylesheet" href="rsd/css/main.css">
        <link rel="stylesheet" href="rsd/css/rsd.css">
        <link rel="stylesheet" href="rsd/css/isotope.css">
        <link rel="stylesheet" href="rsd/css/responsive.css">
        <link rel="stylesheet" type="text/css" href="rsd/css/vegas/jquery.vegas.css">
        <link rel="stylesheet" href="rsd/css/popup/magnific-popup.css">
 		<link rel="stylesheet" href="rsd/js/superslides-0.6.2/dist/stylesheets/superslides.css">

        <!-- Colors Style -->
        <link rel="stylesheet" href="rsd/css/color/dark.css">
        <link rel="stylesheet" href="rsd/css/color/black.css">
        <link rel="stylesheet" href="rsd/css/color/green.css">
        <link rel="stylesheet" href="rsd/css/color/red.css">
        <link rel="stylesheet" href="rsd/css/color/yellow.css">
        <link rel="stylesheet" href="rsd/css/color/purple.css">
        <link rel="stylesheet" href="rsd/css/color/turquoise.css">
        <link rel="stylesheet" href="rsd/css/color/orange.css">
        <link rel="stylesheet" href="rsd/css/color/blue.css">

        <script src="rsd/js/vendor/modernizr-2.6.2.min.js"></script>
        <script src="js/jssor.slider-26.7.0.min.js" type="text/javascript"></script>
        <script src="js/jssor.slider-26.7.0.min.js" type="text/javascript"></script>
    <script type="text/javascript">
        jssor_1_slider_init = function() {

            var jssor_1_SlideoTransitions = [
              [{b:0,d:600,y:-290,e:{y:27}}],
              [{b:0,d:1000,y:185},{b:1000,d:500,o:-1},{b:1500,d:500,o:1},{b:2000,d:1500,r:360},{b:3500,d:1000,rX:30},{b:4500,d:500,rX:-30},{b:5000,d:1000,rY:30},{b:6000,d:500,rY:-30},{b:6500,d:500,sX:1},{b:7000,d:500,sX:-1},{b:7500,d:500,sY:1},{b:8000,d:500,sY:-1},{b:8500,d:500,kX:30},{b:9000,d:500,kX:-30},{b:9500,d:500,kY:30},{b:10000,d:500,kY:-30},{b:10500,d:500,c:{x:125.00,t:-125.00}},{b:11000,d:500,c:{x:-125.00,t:125.00}}],
              [{b:0,d:600,x:535,e:{x:27}}],
              [{b:-1,d:1,o:-1},{b:0,d:600,o:1,e:{o:5}}],
              [{b:-1,d:1,c:{x:250.0,t:-250.0}},{b:0,d:800,c:{x:-250.0,t:250.0},e:{c:{x:7,t:7}}}],
              [{b:-1,d:1,o:-1},{b:0,d:600,x:-570,o:1,e:{x:6}}],
              [{b:-1,d:1,o:-1,r:-180},{b:0,d:800,o:1,r:180,e:{r:7}}],
              [{b:0,d:1000,y:80,e:{y:24}},{b:1000,d:1100,x:570,y:170,o:-1,r:30,sX:9,sY:9,e:{x:2,y:6,r:1,sX:5,sY:5}}],
              [{b:2000,d:600,rY:30}],
              [{b:0,d:500,x:-105},{b:500,d:500,x:230},{b:1000,d:500,y:-120},{b:1500,d:500,x:-70,y:120},{b:2600,d:500,y:-80},{b:3100,d:900,y:160,e:{y:24}}],
              [{b:0,d:1000,o:-0.4,rX:2,rY:1},{b:1000,d:1000,rY:1},{b:2000,d:1000,rX:-1},{b:3000,d:1000,rY:-1},{b:4000,d:1000,o:0.4,rX:-1,rY:-1}]
            ];

            var jssor_1_options = {
              $AutoPlay: 1,
              $Idle: 2000,
              $Cols: 1,
              $Align: 0,
              $CaptionSliderOptions: {
                $Class: $JssorCaptionSlideo$,
                $Transitions: jssor_1_SlideoTransitions,
                $Breaks: [
                  [{d:2000,b:1000}]
                ]
              },
              $ArrowNavigatorOptions: {
                $Class: $JssorArrowNavigator$
              },
              $BulletNavigatorOptions: {
                $Class: $JssorBulletNavigator$
              }
            };

            var jssor_1_slider = new $JssorSlider$("jssor_1", jssor_1_options);

            /*#region responsive code begin*/

            var MAX_WIDTH = 980;

            function ScaleSlider() {
                var containerElement = jssor_1_slider.$Elmt.parentNode;
                var containerWidth = containerElement.clientWidth;

                if (containerWidth) {

                    var expectedWidth = Math.min(MAX_WIDTH || containerWidth, containerWidth);

                    jssor_1_slider.$ScaleWidth(expectedWidth);
                }
                else {
                    window.setTimeout(ScaleSlider, 30);
                }
            }

            ScaleSlider();

            $Jssor$.$AddEvent(window, "load", ScaleSlider);
            $Jssor$.$AddEvent(window, "resize", ScaleSlider);
            $Jssor$.$AddEvent(window, "orientationchange", ScaleSlider);
            /*#endregion responsive code end*/
        };
        jssor_2_slider_init = function() {

            var jssor_2_SlideoTransitions = [
              [{b:0,d:600,y:-290,e:{y:27}}],
              [{b:0,d:1000,y:185},{b:1000,d:500,o:-1},{b:1500,d:500,o:1},{b:2000,d:1500,r:360},{b:3500,d:1000,rX:30},{b:4500,d:500,rX:-30},{b:5000,d:1000,rY:30},{b:6000,d:500,rY:-30},{b:6500,d:500,sX:1},{b:7000,d:500,sX:-1},{b:7500,d:500,sY:1},{b:8000,d:500,sY:-1},{b:8500,d:500,kX:30},{b:9000,d:500,kX:-30},{b:9500,d:500,kY:30},{b:10000,d:500,kY:-30},{b:10500,d:500,c:{x:125.00,t:-125.00}},{b:11000,d:500,c:{x:-125.00,t:125.00}}],
              [{b:0,d:600,x:535,e:{x:27}}],
              [{b:-1,d:1,o:-1},{b:0,d:600,o:1,e:{o:5}}],
              [{b:-1,d:1,c:{x:250.0,t:-250.0}},{b:0,d:800,c:{x:-250.0,t:250.0},e:{c:{x:7,t:7}}}],
              [{b:-1,d:1,o:-1},{b:0,d:600,x:-570,o:1,e:{x:6}}],
              [{b:-1,d:1,o:-1,r:-180},{b:0,d:800,o:1,r:180,e:{r:7}}],
              [{b:0,d:1000,y:80,e:{y:24}},{b:1000,d:1100,x:570,y:170,o:-1,r:30,sX:9,sY:9,e:{x:2,y:6,r:1,sX:5,sY:5}}],
              [{b:2000,d:600,rY:30}],
              [{b:0,d:500,x:-105},{b:500,d:500,x:230},{b:1000,d:500,y:-120},{b:1500,d:500,x:-70,y:120},{b:2600,d:500,y:-80},{b:3100,d:900,y:160,e:{y:24}}],
              [{b:0,d:1000,o:-0.4,rX:2,rY:1},{b:1000,d:1000,rY:1},{b:2000,d:1000,rX:-1},{b:3000,d:1000,rY:-1},{b:4000,d:1000,o:0.4,rX:-1,rY:-1}]
            ];

            var jssor_2_options = {
              $AutoPlay: 1,
              $Idle: 2000,
              $Cols: 1,
              $Align: 0,
              $CaptionSliderOptions: {
                $Class: $JssorCaptionSlideo$,
                $Transitions: jssor_2_SlideoTransitions,
                $Breaks: [
                  [{d:2000,b:1000}]
                ]
              },
              $ArrowNavigatorOptions: {
                $Class: $JssorArrowNavigator$
              },
              $BulletNavigatorOptions: {
                $Class: $JssorBulletNavigator$
              }
            };

            var jssor_2_slider = new $JssorSlider$("jssor_2", jssor_2_options);

            /*#region responsive code begin*/

            var MAX_WIDTH = 980;

            function ScaleSlider() {
                var containerElement = jssor_2_slider.$Elmt.parentNode;
                var containerWidth = containerElement.clientWidth;

                if (containerWidth) {

                    var expectedWidth = Math.min(MAX_WIDTH || containerWidth, containerWidth);

                    jssor_2_slider.$ScaleWidth(expectedWidth);
                }
                else {
                    window.setTimeout(ScaleSlider, 30);
                }
            }

            ScaleSlider();

            $Jssor$.$AddEvent(window, "load", ScaleSlider);
            $Jssor$.$AddEvent(window, "resize", ScaleSlider);
            $Jssor$.$AddEvent(window, "orientationchange", ScaleSlider);
            /*#endregion responsive code end*/
        };
    </script>
    <link href="https://fonts.googleapis.com/css?family=Oswald:200,300,regular,500,600,700&subset=latin-ext,vietnamese,latin,cyrillic" rel="stylesheet" type="text/css" >
    <style>
        /* jssor slider loading skin spin css */
        .jssorl-009-spin img {
            animation-name: jssorl-009-spin;
            animation-duration: 1.6s;
            animation-iteration-count: infinite;
            animation-timing-function: linear;
        }

        @keyframes jssorl-009-spin {
            from {
                transform: rotate(0deg);
            }

            to {
                transform: rotate(360deg);
            }
        }


        .jssorb052 .i {position:absolute;cursor:pointer;}
        .jssorb052 .i .b {fill:#000;fill-opacity:0.3;}
        .jssorb052 .i:hover .b {fill-opacity:.7;}
        .jssorb052 .iav .b {fill-opacity: 1;}
        .jssorb052 .i.idn {opacity:.3;}

        .jssora053 {display:block;position:absolute;cursor:pointer;}
        .jssora053 .a {fill:none;stroke:#fff;stroke-width:640;stroke-miterlimit:10;}
        .jssora053:hover {opacity:.8;}
        .jssora053.jssora053dn {opacity:.5;}
        .jssora053.jssora053ds {opacity:.3;pointer-events:none;}
    </style>

    </head>
    <body>
<!--    	<div id="mask">
            <div class="loader">
              <img src="rsd/img/loading.gif" alt='loading'>
            </div>
        </div>-->

    	<div id="anchor1"></div>

          <div id="slides-1">
          	<div class="overlay"></div>
            <div class="slides-container">
              <img src="rsd/img/slider/03.jpg" alt="">
              <img src="rsd/innomep_images/slider/image5.jpeg" alt="">
              <img src="rsd/img/slider/01.jpg" alt="">
              <img src="rsd/img/slider/02.jpg" alt="">
            </div>
            <nav class="slides-navigation">
              <a href="#" class="next"></a>
              <a href="#" class="prev"></a>
            </nav>
          </div>

        <!--<section id="home" class="clear">-->
            <!--<div id="anchor1">--><!--<div>
                <ul class="slider-controls">
                    <li><a id="vegas-next" class="s-next" href="#"></a></li>
                    <li><a id="vegas-prev" class="s-prev" href="#"></a></li>
                </ul>
            </div>
        </section>-->
        <div class="main-title">
            <div class="title-container">
                <ul>
                    <li class="t-current">We are INNOMEP</li>
                    <li>We are INNOMEP</li>
                    <li>We are INNOMEP</li>
                </ul>
                <div class="spacer"></div>
                <!--<a href="#anchor2"><div class="slider-logo">Get Started</div></a>-->
                <div class="second-title">We build perfection, so you can get a product which complies with our quality standarts. Take action & keep it simple.</div>
                <a href="#anchor2"><div class="buy-logo">Get Started<span></span></div></a>
        	</div>
        </div>
        <div id="logx"></div>
        <header class="header">
            <div class="logo"><img style="height: 68px !important; width: 51px !important;" src="rsd/innomep_images/innomep_logo.png"></div>
            <nav id="nav2" role="navigation">
                <a class="jump-menu" title="Show navigation">Show navigation</a>
                <ul>
                    <li class="current"><a href="#anchor1">home</a></li>
                    <li><a href="#anchor2">about</a></li>
                    <li><a href="#anchor4">services</a></li>
                    <li><a href="#anchor7">advisory board</a></li>
                    <li><a href="#anchor3">team</a></li>
                    <li><a href="#anchor5">projects</a></li>
                    <li><a href="#anchor6">contact</a></li>
                </ul>
            </nav>
            <nav class="menu">
                <ul id="nav">
                    <li class="current"><a href="#anchor1">home</a></li>
                    <li><a href="#anchor2">about</a></li>
                    <li><a href="#anchor4">services</a></li>
                    <li><a href="#anchor7">advisory board</a></li>
                    <li><a href="#anchor3">team</a></li>
                    <li><a href="#anchor5">projects</a></li>
                    <li><a href="#anchor6">contact</a></li>
                </ul>
            </nav>
        </header>