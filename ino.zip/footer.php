<footer id=anchor6 class="footer light">
            <div class="footer-container">
            	<div class="title one no-top">Contact</div>
                <div class="spacer"></div>
                <div class="title two f-bottom">We build perfection, so you can get a product which complies with our quality standarts.<br> Take action & keep it simple!</div>
                <div class="foot-third hideme dontHide">
                    <div class="f-title-two">Visit Our Office</div>
                    <div class="f-data adress"><img src="rsd/img/adress-ico.png" alt='img'> Adress: <span>Markaz Building, 2nd Floor, Mayanad Road, Medical College, Calicut – 673008</span></div>
                    <div class="f-data phone"><img src="rsd/img/phone-ico.png" alt='img'> Phone: <span>+918606911133</span></div>
                    <div class="f-data e-mail"><img src="rsd/img/mail-ico.png" alt='img'> Email: <span>shaharzad786@gmail.com</span></div>
                </div>
                <div class="foot-third hideme dontHide">
                    <div class="f-title-two">Business Hours</div>
                    <div class="f-data hour-1"><img src="rsd/img/hours-ico.png" alt='img'> Mon. - Fri. <span>8am to 5pm</span></div>
                    <div class="f-data hour-2"><img src="rsd/img/hours-ico.png" alt='img'> Sat. <span>8am to 11am</span></div>
                    <div class="f-data hour-3"><img src="rsd/img/hours-ico.png" alt='img'> Sun. <span>Closed</span></div>
                </div>
                <div class="foot-third hideme dontHide">
                	<form method="post" id="contact" class="peThemeContactForm" action="mail.php">
                        <div class="notifications">
                            <div id="contactFormSent" class="formSent alert alert-success">
                                <strong>Your Message Has Been Sent!</strong> Thank you for contacting us.</div>
                            <div id="contactFormError" class="formError alert alert-error">
                                <strong>Oops, An error has ocurred!</strong> See the marked fields above to fix the errors.</div>
                        </div>    
                        <div id="personal" class="bay form-horizontal">
                            <div class="control-group"><!--name field-->
                                <div class="controls">
                                    <input class="required span9" type="text" name="author" data-fieldid="0" placeholder="Your Name" onclick="if(this.value=='Full Name') this.value=''" onblur="if(this.value=='') this.value='Full Name'">
                                </div>
                            </div>
                            <div class="control-group"><!--email field-->
                                <div class="controls">
                                    <input class="required span9" type="email" name="email" data-fieldid="1" placeholder="Your Email" onclick="if(this.value=='Your Email') this.value=''" onblur="if(this.value=='') this.value='Your Email'">
                                </div>
                            </div>
                            <div class="control-group"><!--message field-->
                                <div class="controls">
                                    <textarea name="message" rows="12" class="required span9" data-fieldid="2" onclick="if(this.value=='Type Message') this.value=''" onblur="if(this.value=='') this.value='Type Message'">Type Message</textarea>
                                </div>
                            </div>
                            <div class="control-group">
                                <div class="controls send-btn">
                                    <button type="submit" class="contour-btn red">Send Message</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </footer>
<a href="#" class="scrollup"><span style="color: black;font-weight: bold;">^</span></a>
<!--        <div id="maps">
			<script type="text/javascript" src="http://maps.google.com/maps/api/js?key=AIzaSyBp9pQ8_FAaO-GlwFjfhW999KdQFtY5dfg"></script>
            <div class="map-content">
            	<div class="wpgmappity_container inner-map" id="wpgmappitymap"></div>
            </div>
        </div>-->
        <div>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3912.8325138435075!2d75.83756631458304!3d11.27371925290068!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ba65948f22bc235%3A0x564900f3ee714dc8!2sInnomep+Engineering!5e0!3m2!1sen!2sin!4v1530707961737" width="100%" height="300" frameborder="0" style="border:0" allowfullscreen></iframe>
        </div>
        <div class="socialFooter">
        	<div class="social-icons">
                <div class="social">
                    <a href="https://www.facebook.com/" target="_blank"><div class="face"></div></a>
                    <a href="https://twitter.com/" target="_blank"><div class="twitt"></div></a>
                    <a href="https://plus.google.com/" target="_blank"><div class="plus"></div></a>
                </div>
            </div>
            <div class="clear"></div>
            <div class="copy">2018 © innomep. All rights reserved.</div>
        </div>
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="rsd/js/vendor/jquery-1.9.1.min.js"><\/script>')</script>
        <script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.9.2/jquery-ui.min.js"></script>
        <script type="text/javascript" src="rsd/js/jquery.carouFredSel-6.2.1-packed.js"></script>
        <script src="rsd/js/jquery.smoothwheel.js"></script>
        <script src="rsd/js/main.js"></script>
        <script src="rsd/js/jquery.inview.js"></script>
        <script type="text/javascript" 	src="rsd/js/jquery.sticky.js"></script>
        <script type="text/javascript" src="rsd/js/caroussel/jquery.easing.1.3.js"></script>
        <script type="text/javascript" 	src="rsd/js/portfolio.js"></script>
        <!--<script type="text/javascript" src="js/vegas/jquery.vegas.js"></script>-->
		<script src="rsd/js/superslides-0.6.2/dist/jquery.superslides.js" type="text/javascript" charset="utf-8"></script>

        <script type="text/javascript" src="rsd/js/jquery.hoverdir.js"></script>
        <script src="rsd/js/jquery.nav.js"></script>
        <script src="rsd/js/popup/jquery.magnific-popup.js"></script>
		<script type="text/javascript" src="rsd/js/caroussel/jquery.contentcarousel.js"></script>
		<script src="rsd/js/jquery.isotope.min.js"></script>
        <script src="rsd/js/plugins.js"></script>
        <!--<script type="text/javascript" src="js/vegas/vegas_slider.js"></script>-->
        <script src="rsd/js/jquery.validate.js"></script>
        <script src="rsd/js/jquery.form.js"></script>
        <script src="rsd/js/test.js"></script>
        <script src="rsd/js/superslides.js"></script>
    </body>
</html>
<script>
    $('.logo').on('click', function() {
       location.reload(); 
    });
</script>