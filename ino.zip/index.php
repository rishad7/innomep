<?php include 'header.php'; ?>
    <div class="rsdMainDiv">    
        <article id="anchor2" class="content menu-top dark">
        	<header class="title one">About Us</header>
            <div class="spacer"></div>
            <div class="title two">
                <p><span style="color: black;font-weight: bold;">Innomep Engineering</span> is one of the eﬃciently designing MEP service provider in this heart of new age modern and complicated buildings. It is very critical that MEP services should be designed with detailed and latest engineering technologies.</p>
                <p><span style="color: black;font-weight: bold;">Innomep Engineering</span> specializes in MEP consulting and contracting is owned by experienced, energetic, creative and young engineers. We believe in providing totally integrated and innovative engineering design solutions for the best performance of the building.</p>
                <p>We oﬀer uniﬁed approach to fulﬁll a magnitude of services, delivering the promised speciﬁc requirements for each projects with great excellent ability within the pre‐established ﬁnancial and me limits.</p>
            </div>
            
        </article>
        <article class="content light">
        	<div class="full">
            	<section class="half car-show-1">
                    <div class="show hideme dontHide">
                        <div class="caroussel">
                            <div class="caroussel-list">
                                <div class="car-img"><img src="rsd/innomep_images/our_core_principles.jpg" alt='img'></div>
                                <div class="car-img"><img src="rsd/innomep_images/our_services.jpg" alt='img'></div>
                                <div class="car-img"><img src="rsd/innomep_images/scope_of_services.jpg" alt='img'></div>
                            </div>
                        </div>
                        <div class="car-prev"></div>
                        <div class="car-next"></div>
                    </div>
                    <div class="controller">
                    	<ul>
                        </ul>
                    </div>
                </section>
                <section class="half">
                    <div class="title-two" style="padding-bottom: 25px !important;">VISION</div>
                    <div style="text-align: center;" class="half-content hideme dontHide">
                    	To become a world class MEP quality service provider ensuring sustainable environmental management using innovative and eco-friendly techniques.
                    </div>
                    <div class="title-two" style="padding-bottom: 25px !important; padding-top: 15px;">MISSION</div>
                    <div style="text-align: center;" class="half-content hideme dontHide">
                    	To become the most reputed and valued company by designing, planning and costing of Electrical, Mechanical and Plumbing services in eco-friendly and innovative ways that will enrich society needs.
                    </div>
                </section>
            </div>
            <div class="clear"></div>
        </article>
                <article id=anchor4 class="content dark">
        	<header class="title one">Our Services</header>
            <div class="spacer"></div>
            <div class="title two">Concept Design and estimates of electrical, plumbing and fire fighting systems</div>
            <div class="s-container services-container">
                <section class="services">
                       <!--<div class="s-element">
                            <div class="s-ico"></div>
                            <div class="s-info"><span>Developer Track</span><br><br>Quis aute iure reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Stet clita kasd gubergren.</div>
                        </div>
                        <div class="s-element">
                            <div class="s-ico"></div>
                            <div class="s-info"><span>SEO Analytics</span><br><br>Quis aute iure reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Stet clita kasd gubergren.</div>
                        </div>
                        <div class="s-element">
                            <div class="s-ico"></div>
                            <div class="s-info"><span>Amazing Ideas</span><br><br>Quis aute iure reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Stet clita kasd gubergren.</div>
                        </div>-->
                        <div class="sl-element hideme dontHide">
                            <div class="sl-ico sl-config"></div>
                            <div class="sl-title">Detailed Engineering</div>
                        </div>
                        <div class="sl-element hideme dontHide">
                            <div class="sl-ico sl-diamond"></div>
                            <div class="sl-title">Tendering, Evaluation and recommendations</div>
                        </div>
                        <div class="sl-element hideme dontHide">
                            <div class="sl-ico sl-globe"></div>
                            <div class="sl-title">Project Management and implementation with quality and excellent workmanship</div>
                        </div>
                        <div class="sl-element hideme dontHide">
                            <div class="sl-ico sl-pointer"></div>
                            <div class="sl-title">Documentation and contract closing</div>
                        </div>
                        <div class="sl-element hideme dontHide">
                            <div class="sl-ico sl-clock"></div>
                            <div class="sl-title">Comprehensive solar solutions including on grid and off grid systems</div>
                        </div>
                        <div class="sl-element hideme dontHide">
                            <div class="sl-ico sl-config"></div>
                            <div class="sl-title">Total building automation to enhance efficiency and management of the systems</div>
                        </div>
                        <div class="clear"></div>
               </section>
           </div>
        </article>
        <article class="content light">
            <header class="title one">Scope Industry</header>
            <div class="spacer"></div>
            <div class="title two">We have Engineers associated with other qualified supporting staff fully equipped to offer engineering solutions for all Electro Mechanical services including.</div>
        	<div class="full">
                <section class="half hideme dontHide">
                    <div class="half-content">
                    	<div class="sk-container">
                            <div class="skill-content">
                                <div class="progress-bar skill-1">
                                    <div class="skill-in" title="100"><div class="info-skills" style="color: black;">Residences</div></div>
                                </div>
                            </div>
                            <div class="skill-content">
                                <div class="progress-bar skill-1">
                                  <div class="skill-in" title="100"><div class="info-skills" style="color: black;">Apartments</div></div>
                                </div>
                            </div>
                            <div class="skill-content">
                                <div class="progress-bar skill-1">
                                  <div class="skill-in" title="100"><div class="info-skills" style="color: black;">Gated Community</div></div>
                                </div>
                            </div>
                            <div class="skill-content">
                                <div class="progress-bar skill-1">
                                  <div class="skill-in" title="100"><div class="info-skills" style="color: black;">High rise Buildings</div></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <section class="half hideme dontHide">
                    <div class="half-content">
                    	<div class="sk-container">
                            <div class="skill-content">
                                <div class="progress-bar skill-1">
                                  <div class="skill-in" title="100"><div class="info-skills" style="color: black;">Banks and Offices</div></div>
                                </div>
                            </div>
                            <div class="skill-content">
                                <div class="progress-bar skill-1">
                                  <div class="skill-in" title="100"><div class="info-skills" style="color: black;">Commercial Buildings</div></div>
                                </div>
                            </div>
                            <div class="skill-content">
                                <div class="progress-bar skill-1">
                                  <div class="skill-in" title="100"><div class="info-skills" style="color: black;">Institutional Buildings</div></div>
                                </div>
                            </div>
                            <div class="skill-content">
                                <div class="progress-bar skill-1">
                                  <div class="skill-in" title="100"><div class="info-skills" style="color: black;">Villas and Bungalows</div></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <div class="clear"></div>
        </article>
        <div class="clear"></div>
        <article class="content light">
        	<section class="full">
                    <div class="title-full-two">TEAM STRENGTH</div>
                <div class="f-container">
                    <div class="f-element hideme dontHide">
                        <div class="f-ico s-three"></div>
                        <div class="milestone-counter" data-perc="50">
                       		<span class="milestone-count highlight">0</span> <!-- Initial Value = 0 -->
                            <div class="milestone-details">50 Years of combined experience in design and implementation of MEP projects ACROSS India</div>
                        </div>
                    </div>
                    <div class="f-element hideme dontHide">
                        <div class="f-ico s-two"></div>
                        <div class="milestone-counter" data-perc="85">
                       		<span class="milestone-count highlight">0</span> <!-- Initial Value = 0 -->
                            <div class="milestone-details">ADVISORY BOARD WITH 85 YEARS OF COMBINED EXPERIENCE IN DIFFERENT FIELDS</div>
                        </div>
                    </div>
                </div>
            </section>
            <div class="clear"></div>
        </article>
        <article id=anchor7 class="content dark">
            <header class="title one">Advisory Board</header>
            <div class="spacer"></div>
            <div class="title two"></div>
            <section class="team-box">
                <div class="s-container team-grid">
                    <div class="t-list">
                        <div class="t-element hideme dontHide">
                        	<div class="t-photo">
                                    <div class="image-hover-overlay">
                                        <div style="margin-left: 5px;margin-right: 5px;font-size: 13px;line-height: 20px;" class="details">
                                            <ul class="feature-list">
                                                <li><span class="list-dot"></span>27 years of experience as Consultant, Project Manager, Head of Planning, Scientist, General Manager, in India and Middle East</li>
                                                <li><span class="list-dot"></span>Currently as CEO of Markaz Knowledge City</li>
                                                <li><span class="list-dot"></span>Consultant to Saudi Arabia (Makkah and Madinah), UAE, State of Qatar in various projects</li>
                                                <li><span class="list-dot"></span>Former Scientist Indian Space Research Organization and NIC, Planning Commission</li>
                                                <li><span class="list-dot"></span>Lead National Level Projects in India and Middle East</li>
                                            </ul>
                                        </div>
                                    </div>
                            	<img style="width: 255px; height: 330px;" src="rsd/innomep_images/advisory_board/image7.jpeg" alt='img'>
                            </div>
                            <div class="t-data">
                            	<div class="t-name">Dr.Abdul Salam Mohammed</div>
                                <div class="t-info">Phd, MTech, BTech</div>
                                <div class="t-info">Chief Advisory Consultant</div>
                                <div class="t-spacer"></div>
                            </div>
                        </div>
                        <div class="t-element hideme dontHide">
                        	<div class="t-photo">
                                    <div class="image-hover-overlay">
                                        <div style="margin-left: 5px;margin-right: 5px;font-size: 12px;line-height: 15px;" class="details">
                                            <ul class="feature-list">
                                                <li><span class="list-dot"></span>21 years of experience in managing business strategy and operational improvement projects, even including National Head</li>
                                                <li><span class="list-dot"></span>Currently as COO of Markaz Knowledge City</li>
                                                <li><span class="list-dot"></span>Diverse industries experience such as consumer products, IT, Oil, distribution, industrial in India and Middle East</li>
                                                <li><span class="list-dot"></span>Key positions in HP, Dubai Naturalization and Residency (DNRD)and Abu Dhabi National Oil Refining (TAKREER)</li>
                                                <li><span class="list-dot"></span>Expert in managing large team to deliver high quality results</li>
                                                <li><span class="list-dot"></span>Has created solutions and opportunities for more than 100 clients by constant thinking, advising and working on behalf of them</li>
                                            </ul>
                                        </div>
                                    </div>
                                <img style="width: 255px;height: 330px;" src="rsd/innomep_images/advisory_board/image8.jpeg" alt='img'>
                            </div>
                            <div class="t-data">
                            	<div class="t-name">E V Abdul Rahman</div>
                                <div class="t-info">Project Manager</div>
                                <div class="t-spacer"></div>
                            </div>
                        </div>
                        <div class="t-element hideme dontHide">
                        	<div class="t-photo">
                                    <div class="image-hover-overlay">
                                    <div style="margin-left: 5px;margin-right: 5px;font-size: 13px;line-height: 20px;" class="details">
                                            <ul class="feature-list">
                                                <li><span class="list-dot"></span>38 years of experience in construction field</li>
                                                <li><span class="list-dot"></span>Currently as Chief Physical Development Officer at Markaz Knowledge City</li>
                                                <li><span class="list-dot"></span>Worked in State and Central PWD</li>
                                                <li><span class="list-dot"></span>Construction of Calicut Medical College and several government Buildings in Kerala</li>
                                            </ul>
                                        </div>
                                </div>
                            	<img style="width: 255px; height: 330px;" src="rsd/innomep_images/advisory_board/image9.jpeg" alt='img'>
                            </div>
                            <div class="t-data">
                            	<div class="t-name">Er.Moidheen Koya</div>
                                <div class="t-info">Advisory Board Member</div>
                                <div class="t-spacer"></div>
                            </div>
                        </div>
                        <div class="t-element hideme dontHide">
                        	<div class="t-photo">
                                    <div class="image-hover-overlay">
                                        <div style="margin-left: 5px;margin-right: 5px;font-size: 13px;line-height: 20px;" class="details">
                                            <ul class="feature-list">
                                                <li><span class="list-dot"></span>12 years of experience in both Indian and Multi-National companies in administration and public relation field</li>
                                                <li><span class="list-dot"></span>Currently working as General Manager in Markaz Knowledge City</li>
                                                <li><span class="list-dot"></span>Worked in organizations like Consulate General of Malaysia-Dubai and UAE Prime minister’s Personnel office</li>
                                                <li><span class="list-dot"></span>Experienced in :
                                                    <ul style="margin-left: 10px;" class="feature-list">
                                                        <li><span class="list-dot"></span>Management Reporting</li>
                                                        <li><span class="list-dot"></span>Tracking</li>
                                                        <li><span class="list-dot"></span>Analysing</li>
                                                        <li><span class="list-dot"></span>Delivering information with Excellent Office administration skill</li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                            	<img style="width: 255px; height: 330px;" src="rsd/innomep_images/advisory_board/image10.jpeg" alt='img'>
                            </div>
                            <div class="t-data">
                            	<div class="t-name">Shoukath Ali</div>
                                <div class="t-info">Admin Advisor</div>
                                <div class="t-spacer"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <div class="clearfix"></div>
        </article>
        <article id=anchor3 class="content dark">
        	<header class="title one">Our Team</header>
            <div class="spacer"></div>
            <div class="title two"></div>
            <section class="team-box">
                <div class="s-container team-grid">
                    <div class="t-list">
                        <div class="t-element hideme dontHide">
                        	<div class="t-photo">
                                    <div class="image-hover-overlay">
                                        <div style="margin-left: 5px;margin-right: 5px;font-size: 13px;line-height: 20px;" class="details">
                                            <ul class="feature-list">
                                                <li><span class="list-dot"></span>43 years of experience in the Electrical field, of which 8 years in the KSEB</li>
                                                <li><span class="list-dot"></span>Competent to execute all electrical installation and having ‘A’ grade Supervisor permit of all electrical installation issued by Kerala Electricity Licensing Board</li>
                                                <li><span class="list-dot"></span>Experienced in Designing and Execution of Electrical Installation of :
                                                    <ul style="margin-left: 10px;" class="feature-list">
                                                        <li><span class="list-dot"></span>Industrial Buildings</li>
                                                        <li><span class="list-dot"></span>Commercial Buildings</li>
                                                        <li><span class="list-dot"></span>Institutional Buildings</li>
                                                        <li><span class="list-dot"></span>Electricity generating, Transmission and Distribution projects</li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                            	<img style="width: 255px; height: 330px;" src="rsd/innomep_images/team/image11.jpg" alt='img'>
                            </div>
                            <div class="t-data">
                            	<div class="t-name">A.P Mohanan</div>
                                <div class="t-info">Chief Electrical Consultant</div>
                                <div class="t-spacer"></div>
                            </div>
                        </div>
                        <div class="t-element hideme dontHide">
                        	<div class="t-photo">
                                    <div class="image-hover-overlay">
                                        <div style="margin-left: 5px;margin-right: 5px;font-size: 13px;line-height: 20px;" class="details">
                                            <ul class="feature-list">
                                                <li><span class="list-dot"></span>Experienced in project :
                                                    <ul style="margin-left: 10px;" class="feature-list">
                                                        <li><span class="list-dot"></span>Management</li>
                                                        <li><span class="list-dot"></span>Planning</li>
                                                        <li><span class="list-dot"></span>Implementation</li>
                                                        <li><span class="list-dot"></span>Coordination</li>
                                                        <li><span class="list-dot"></span>Follow-up</li>
                                                    </ul>
                                                </li>
                                                <li><span class="list-dot"></span>Specialized in firefighting design and standards in both India and UAE</li>
                                            </ul>
                                        </div>
                                    </div>
                                <img style="width: 255px;" src="rsd/innomep_images/team/image12.jpeg" alt='img'>
                            </div>
                            <div class="t-data">
                            	<div class="t-name">Mohammed Shaharzad</div>
                                <div class="t-info">B-Tech</div>
                                <div class="t-info">Project Manager</div>
                                <div class="t-spacer"></div>
                            </div>
                        </div>
                        <div class="t-element hideme dontHide">
                        	<div class="t-photo">
                                    <div class="image-hover-overlay">
                                        <div style="margin-left: 5px;margin-right: 5px;font-size: 13px;line-height: 20px;" class="details">
                                            <ul class="feature-list">
                                                <li><span class="list-dot"></span>Specialized in :
                                                    <ul style="margin-left: 10px;" class="feature-list">
                                                        <li><span class="list-dot"></span>Electrical Design</li>
                                                        <li><span class="list-dot"></span>Supervision</li>
                                                    </ul>
                                                </li>
                                                <li><span class="list-dot"></span>Experienced in :
                                                    <ul style="margin-left: 10px;" class="feature-list">
                                                        <li><span class="list-dot"></span>Project costing</li>
                                                        <li><span class="list-dot"></span>Scheduling</li>
                                                        <li><span class="list-dot"></span>HT and LT Scheme Planning</li>
                                                        <li><span class="list-dot"></span>Scheme Preparation</li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                            	<img style="width: 255px; height: 330px;" src="rsd/innomep_images/team/image13.jpeg" alt='img'>
                            </div>
                            <div class="t-data">
                            	<div class="t-name">Muhammed Rishal</div>
                                <div class="t-info">B-Tech</div>
                                <div class="t-info">MEP Manager</div>
                                <div class="t-spacer"></div>
                            </div>
                        </div>
                        <div class="t-element hideme dontHide">
                        	<div class="t-photo">
                                    <div class="image-hover-overlay">
                                        <div style="margin-left: 5px;margin-right: 5px;font-size: 13px;line-height: 20px;" class="details">
                                            <ul class="feature-list">
                                                <li><span class="list-dot"></span>Experienced in :
                                                    <ul style="margin-left: 10px;" class="feature-list">
                                                        <li><span class="list-dot"></span>Business Development</li>
                                                        <li><span class="list-dot"></span>Costing</li>
                                                        <li><span class="list-dot"></span>Financial Management</li>
                                                        <li><span class="list-dot"></span>Office Administration</li>
                                                        <li><span class="list-dot"></span>Risk Management</li>
                                                        <li><span class="list-dot"></span>Problem Solving</li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                            	<img style="width: 255px; height: 330px;" src="rsd/innomep_images/team/image14.jpeg" alt='img'>
                            </div>
                            <div class="t-data">
                            	<div class="t-name">Muhammed Suneer</div>
                                <div class="t-info">Business Development Manager</div>
                                <div class="t-spacer"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <div class="clearfix"></div>
        </article>
        <div class="clear"></div>
        <article id=anchor5 class="content light">
        	<header class="title one">COMPLETED PROJECTS – CONSULTING AND SUPERVISION</header>
            <div class="spacer"></div>
            <div class="title two"></div>
            <div id="portfolio" class="container">
                
                
                <div id="jssor_1" style="position:relative;margin:0 auto;top:0px;left:0px;width:980px;height:380px;overflow:hidden;visibility:hidden;">
        <!-- Loading Screen -->
        <div data-u="loading" class="jssorl-009-spin" style="position:absolute;top:0px;left:0px;width:100%;height:100%;text-align:center;background-color:rgba(0,0,0,0.7);">
            <img style="margin-top:-19px;position:relative;top:50%;width:38px;height:38px;" src="img/spin.svg" >
        </div>
        <div data-u="slides" style="cursor:default;position:relative;top:0px;left:0px;width:980px;height:380px;overflow:hidden;">
            <div data-p="170.00">
                <img data-u="image" src="rsd/innomep_images/projects/image20.jpeg" >
                <div data-u="caption" data-t="0" style="position:absolute;top:320px;left:30px;height:auto;background-color:rgba(255,188,5,0.8);font-family:Oswald,sans-serif;font-size:32px;font-weight:200;line-height:1.2;text-align:center;">
                    Law College at Markaz Knowledge City
                    <li>Total Area : 45,000 Sqft</li>
                </div>
            </div>
            <div data-p="170.00">
                <img data-u="image" src="rsd/innomep_images/projects/image21.jpeg" >
                <div data-u="caption" data-t="2" style="position:absolute;top:30px;left:-505px;width: 350px;height:auto;background-color:rgba(255,188,5,0.8);font-family:Oswald,sans-serif;font-size:32px;font-weight:200;line-height:1.2;text-align:center;">
                    Rashid Villa at Nadapuram
                    <li>Total Area : 16,000 Sqft</li>
                </div>
            </div>
            <div data-p="170.00">
                <img data-u="image" src="rsd/innomep_images/projects/image22.jpeg" >
                <div data-u="caption" data-t="0" style="position:absolute;top:320px;left:30px;height:auto;background-color:rgba(255,188,5,0.8);font-family:Oswald,sans-serif;font-size:32px;font-weight:200;line-height:1.2;text-align:center;">
                    Special Need School at Markaz Knowledge City
                    <li>Total Area : 12,000 Sqft</li>
                </div>
            </div>
            <div data-p="170.00">
                <img data-u="image" src="rsd/innomep_images/projects/image23.jpeg" >
                <div data-u="caption" data-t="2" style="position:absolute;top:30px;left:-505px;height:auto;background-color:rgba(255,188,5,0.8);font-family:Oswald,sans-serif;font-size:32px;font-weight:200;line-height:1.2;text-align:center;">
                    Markaz Unani Medical College at Markaz Knowledge City
                    <li>Total Area : 30,000 Sqft</li>
                </div>
            </div>
        </div>
        <!-- Bullet Navigator -->
        <div data-u="navigator" class="jssorb052" style="position:absolute;bottom:12px;right:12px;" data-autocenter="1" data-scale="0.5" data-scale-bottom="0.75">
            <div data-u="prototype" class="i" style="width:16px;height:16px;">
                <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                    <circle class="b" cx="8000" cy="8000" r="5800"></circle>
                </svg>
            </div>
        </div>
        <!-- Arrow Navigator -->
        <div data-u="arrowleft" class="jssora053" style="width:55px;height:55px;top:0px;left:25px;" data-autocenter="2" data-scale="0.75" data-scale-left="0.75">
            <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                <polyline class="a" points="11040,1920 4960,8000 11040,14080 "></polyline>
            </svg>
        </div>
        <div data-u="arrowright" class="jssora053" style="width:55px;height:55px;top:0px;right:25px;" data-autocenter="2" data-scale="0.75" data-scale-right="0.75">
            <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                <polyline class="a" points="4960,1920 11040,8000 4960,14080 "></polyline>
            </svg>
        </div>
    </div>
                <script type="text/javascript">jssor_1_slider_init();</script>
                
                
            </div>
            <div class="clear"></div>
        </article>
        <article class="content dark">
        	<header class="title one">ONGOING PROJECTS – MEP CONSULTING AND SUPERVISION</header>
            <div class="spacer"></div>
            <div class="title two"></div>
            <div id="portfolio1" class="container">
                
                
                <div id="jssor_2" style="position:relative;margin:0 auto;top:0px;left:0px;width:980px;height:380px;overflow:hidden;visibility:hidden;">
        <!-- Loading Screen -->
        <div data-u="loading" class="jssorl-009-spin" style="position:absolute;top:0px;left:0px;width:100%;height:100%;text-align:center;background-color:rgba(0,0,0,0.7);">
            <img style="margin-top:-19px;position:relative;top:50%;width:38px;height:38px;" src="img/spin.svg" >
        </div>
        <div data-u="slides" style="cursor:default;position:relative;top:0px;left:0px;width:980px;height:380px;overflow:hidden;">
            <div data-p="170.00">
                <img data-u="image" src="rsd/innomep_images/projects/image24.jpeg" >
                <div data-u="caption" data-t="0" style="position:absolute;top:320px;left:30px;height:auto;background-color:rgba(255,188,5,0.8);font-family:Oswald,sans-serif;font-size:32px;font-weight:200;line-height:1.2;text-align:center;">
                    Markaz Knowledge City in Calicut
                    <li>Design and supervision of 110 kV Substation for MKC</li>
                </div>
            </div>
            <div data-p="170.00">
                <img data-u="image" src="rsd/innomep_images/projects/image25.jpeg" >
                <div data-u="caption" data-t="2" style="position:absolute;top:30px;left:-505px;height:auto;background-color:rgba(255,188,5,0.8);font-family:Oswald,sans-serif;font-size:32px;font-weight:200;line-height:1.2;text-align:center;">
                    MEP Design and Supervision of Cultural Centre in Calicut
                    <li>Total Area : 1,40,000 Sqft</li>
                </div>
            </div>
            <div data-p="170.00">
                <img data-u="image" src="rsd/innomep_images/projects/image26.jpeg" >
                <div data-u="caption" data-t="0" style="position:absolute;top:320px;left:30px;height:auto;background-color:rgba(255,188,5,0.8);font-family:Oswald,sans-serif;font-size:32px;font-weight:200;line-height:1.2;text-align:center;">
                    MEP Design and Supervision of Therapy Training Institute in Markaz Knowledge City
                    <li>Total Area : 1,40,000 Sqft</li>
                </div>
            </div>
            <div data-p="170.00">
                <img data-u="image" src="rsd/innomep_images/projects/image27.jpeg" >
                <div data-u="caption" data-t="2" style="position:absolute;top:30px;left:-505px;height:auto;background-color:rgba(255,188,5,0.8);font-family:Oswald,sans-serif;font-size:32px;font-weight:200;line-height:1.2;text-align:center;">
                    MEP Design of KBA Group Hotel at Manipal
                    <li>Total Area : 70,000 Sqft</li>
                </div>
            </div>
            <div data-p="170.00">
                <img data-u="image" src="rsd/innomep_images/projects/image29.jpeg" >
                <div data-u="caption" data-t="0" style="position:absolute;top:320px;left:30px;height:auto;background-color:rgba(255,188,5,0.8);font-family:Oswald,sans-serif;font-size:32px;font-weight:200;line-height:1.2;text-align:center;">
                    MEP Design of Resort project at Vythiri
                    <li>Total Area : 1,00,000 Sqft</li>
                </div>
            </div>
            <div data-p="170.00">
                <img data-u="image" src="rsd/innomep_images/projects/image30.jpeg" >
                <div data-u="caption" data-t="2" style="position:absolute;top:30px;left:-505px;height:auto;background-color:rgba(255,188,5,0.8);font-family:Oswald,sans-serif;font-size:32px;font-weight:200;line-height:1.2;text-align:center;">
                    Electrical Design of Villa at Uduppi
                    <li>Total Area : 10,000 Sqft</li>
                </div>
            </div>
        </div>
        <!-- Bullet Navigator -->
        <div data-u="navigator" class="jssorb052" style="position:absolute;bottom:12px;right:12px;" data-autocenter="1" data-scale="0.5" data-scale-bottom="0.75">
            <div data-u="prototype" class="i" style="width:16px;height:16px;">
                <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                    <circle class="b" cx="8000" cy="8000" r="5800"></circle>
                </svg>
            </div>
        </div>
        <!-- Arrow Navigator -->
        <div data-u="arrowleft" class="jssora053" style="width:55px;height:55px;top:0px;left:25px;" data-autocenter="2" data-scale="0.75" data-scale-left="0.75">
            <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                <polyline class="a" points="11040,1920 4960,8000 11040,14080 "></polyline>
            </svg>
        </div>
        <div data-u="arrowright" class="jssora053" style="width:55px;height:55px;top:0px;right:25px;" data-autocenter="2" data-scale="0.75" data-scale-right="0.75">
            <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                <polyline class="a" points="4960,1920 11040,8000 4960,14080 "></polyline>
            </svg>
        </div>
    </div>
                <script type="text/javascript">jssor_2_slider_init();</script>
                
                
            </div>
            <div class="clear"></div>
        </article>
    </div>
<?php include 'footer.php'; ?>